//
//  ___FILEBASENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

#import "kiwi.h"
#import "___FILEBASENAME___.h"

SPEC_BEGIN(___FILEBASENAME___Spec)

describe(@"___FILEBASENAME___", ^{
    beforeAll(^{
        //[MagicalRecord setDefaultModelFromClass:[self class]];
        //[MagicalRecord setupCoreDataStackWithInMemoryStore];
    });
    
    afterAll(^{
        //[MagicalRecord cleanUp];
    });
    
    context(@"", ^{
        
    });
});

SPEC_END